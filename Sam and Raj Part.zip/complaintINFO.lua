composer = require( "composer" )
 
local scene = composer.newScene()
 



--Adding Welcome message
--local function header()
--display.newText("Welcome",display.contentCenterX,display.contentCenterY, "Comic Sans MS", 50)
--end
--header()

-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------
 
local widget = require ("widget")

local function Home ()	
	composer.gotoScene("FirstScene",{effect = "slideLeft", time = 500})
end




local function hyperLink()
  system.openURL("https://www.oaic.gov.au/individuals/privacy-complaint-checker/question-1")
end
-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------
 
-- create()
function scene:create( event )
 
    local sceneGroup = self.view
	
	--adding background
	
	background = display.newImage( "background4.png", display.contentCenterX, display.contentCenterY )
	sceneGroup:insert(background)
	
	
	HomeImage = display.newImage("HomeIcon.png", 280, 20 )
	--myImage:translate(140,450)
	sceneGroup:insert(HomeImage)
	HomeImage:addEventListener("tap", Home)
	
	head = display.newText("Complaint", display.contentCenterX*0.90,display.contentCenterY*0.10,"Arial",20)
	head:setFillColor(1,0,0)
	sceneGroup:insert(head)
	
	-- Path for the file to read
local path = system.pathForFile( "file1.txt", system.ResourceDirectory )
 
-- Open the file handle
local file, errorString = io.open( path, "r" )
 

local surveyText = 
{
	text = file:read("*a"),
	x = display.contentCenterX,
			   y = 150,
			   fontSize = native.SystemFont,
			   width = 280,
			   height = 220,
			   align = "left"
}

local function myText1()
	display.newText( surveyText )
end

--before select


    

	local myText1 = display.newText( surveyText )

	local surveyLink = widget.newButton(
	{
		id = "link",
		label = "Click here to complaint",
		onEvent = myeventListener,
		emboss = false,
		x = display.contentCenterX,
		y = 300,
		shape = "roundedRect",

	}
	)
	sceneGroup:insert(surveyLink)
	surveyLink:addEventListener ("touch", hyperLink)
	io.close( file )

	--Adding Timer in this app which display how long a user is seing the app
	
	--sceneGroup:insert(Timer)
	
 
end
 
 
-- show()
function scene:show( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen
 
    end
end
 
 
-- hide()
function scene:hide( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
 
    end
end
 
 
-- destroy()
function scene:destroy( event )
 
    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view
 
end
 
 
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
 
return scene